﻿#pragma once
#include <iostream>


class StoryStart
{
private:


public:
	void startStory();
};