#pragma once
#include <iostream>
#include <fstream>



class StoryOutcome
{
private:


public:
	static void Bad();
	static void Good();
	
	static void Facts();


};

