#pragma once
#include <iostream>

class PlayerDecision

{
private:

	int m_karma;



public:

	//public getters and setters
	void setKarmaCounter(int karma) { m_karma = karma; }
	int getKarmaCounter() { return m_karma; }

};